from nltk.tokenize import word_tokenize
from unidecode import unidecode


def find_kids(parent, dict_id_parent, queue):
	for k in dict_id_parent:
		if dict_id_parent[k] == parent:
			queue.append(k)

def determine_sentences(nucleus, satelites, dict_relations, dict_id_parent, dict_id_segments, dict_id_relations, root):
	queue = []
	find_kids(root, dict_id_parent, queue)
	if root in dict_id_segments.keys():
		nucleus.add(dict_id_segments[root])
		return
	while len(queue) > 0:
		k = queue.pop(0)
		# print('k = '+k)
		if dict_id_segments[k] == 'group' or dict_id_relations[k] == 'span':
			find_kids(k, dict_id_parent, queue)
			if dict_id_parent[k] != root and dict_relations[dict_id_relations[dict_id_parent[k]]] == 'rst':
				dict_id_relations[k] = dict_id_relations[dict_id_parent[k]]
			elif dict_id_parent[k] != root and dict_relations[dict_id_relations[dict_id_parent[k]]] == 'multinuc':
				dict_id_relations[k] = dict_id_relations[dict_id_parent[k]]
			# print('if1')
		if dict_id_segments[k] != 'group' and dict_id_relations[k] == 'span':
			dict_relations[dict_id_relations[k]] = 'multinuc'
		if dict_id_segments[k] != 'group' and dict_relations[dict_id_relations[k]] == 'rst':
			satelites.add(dict_id_segments[k])
			# print('if2')
		elif dict_id_segments[k] != 'group' and dict_relations[dict_id_relations[k]] == 'multinuc':
			nucleus.add(dict_id_segments[k])
			# print('else')
	

for cnt in range(1, 351):
	lines = open('frase'+str(cnt)+'.rs3', 'r').readlines()
	lines = [unidecode(l.decode('utf-8')) for l in lines]
	dict_relations = dict()
	dict_id_segments = dict()
	dict_id_relations = dict()
	dict_id_parent = dict()
	set_relations_rst = set()
	set_relations_multinuc = set()

	root = '-1'
	for l in lines:
		posrelation = l.find('rel name')
		possegment = l.find('segment id')
		posgroup = l.find('group id')

		if posrelation != -1:
			posrelation += len('rel name=\"')
			myString = l[posrelation:(l.find('\"', posrelation, len(l)))]
			postype = l.find('type')
			postype += len('type=\"')
			myRelation = l[postype:(l.find('\"', postype, len(l)))]
			dict_relations[myString] = myRelation
			if myRelation == 'rst':
				set_relations_rst.add(myString)
			else if myRelation == 'multinuc':
				set_relations_multinuc.add(myString)
		# elif possegment != -1:
		# 	possegment += len('segment id=\"')
		# 	myId = l[possegment:(l.find('\"', possegment, len(l)))]
		# 	posparent = l.find('parent')
		# 	if posparent == -1:
		# 		dict_id_parent[myId] = 'root'
		# 		root = myId
		# 	else:
		# 		posparent += len('parent=\"')
		# 		myParent = l[posparent:(l.find('\"', posparent, len(l)))]
		# 		dict_id_parent[myId] = myParent
		# 	posrel = l.find('relname')
		# 	if posrel != -1:
		# 		posrel += len('relname=\"')
		# 		myRelation = l[posrel:(l.find('\"', posrel, len(l)))]
		# 		dict_id_relations[myId] = myRelation
		# 	posrel = l.find('>', posrel, len(l)) + 1
		# 	mySentence = l[posrel:(l.find('<', posrel, len(l)))]
		# 	dict_id_segments[myId] = mySentence
		# elif posgroup != -1:
		# 	posgroup += len('group id=\"')
		# 	myId = l[posgroup:(l.find('\"', posgroup, len(l)))]
		# 	# dict_id_segments[myId] = 'group'
		# 	posparent = l.find('parent')
		# 	if posparent == -1:
		# 		dict_id_parent[myId] = 'root'
		# 		root = myId
		# 	else:
		# 		posparent += len('parent=\"')
		# 		myParent = l[posparent:(l.find('\"', posparent, len(l)))]
		# 		dict_id_parent[myId] = myParent
		# 		dict_id_segments[myId] = 'group'
		# 	posrel = l.find('relname')
		# 	if posrel != -1:
		# 		posrel += len('relname=\"')
		# 		myRelation = l[posrel:(l.find('\"', posrel, len(l)))]
		# 		dict_id_relations[myId] = myRelation

	# dict_relations['span'] = 'multinuc'
	# nucleus = set()
	# satelites = set()
	# determine_sentences(nucleus, satelites, dict_relations, dict_id_parent, dict_id_segments, dict_id_relations, root)
	# print(nucleus)
	# print(satelites)
	file_csv = open('all_relations.txt', 'w')
	for rel in set_relations_rst:
		fwrite(rel+'\n')
	for rel in set_relations_multinuc:
		fwrite(rel+'\n')
	# break
	# for x in dict_relations:
	# 	print(x+" = "+dict_relations[x])
	# print('*********************************')
	# for x in dict_id_relations:
	# 	print(x+" = "+dict_id_relations[x])
	# print('*********************************')
	# for x in dict_id_parent:
	# 	print(x+" = "+dict_id_parent[x])
	# print('*********************************')
	# for x in dict_id_segments:
	# 	print(x+" = "+dict_id_segments[x])
	# print('*********************************')
	# for x in dict_id_relations:
	# 	print(x+" = "+dict_id_relations[x])
	# break


